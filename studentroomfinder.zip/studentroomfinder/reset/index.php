<?php
require_once dirname(__DIR__) . '/application/src/autoload.php';

// session checking, if no set, we will continue to home
// if has been set, we will redirect to dashboard
if (empty($_SESSION['account'])) {

  // if user click verify email, the link redirecting to here
  // with $_GET information about email & verification code;
  // so we direct to link have $_GET method or not
  if (isset($_GET['token_reset'])) {
    if (!empty($_POST)) {

      if (!empty($_POST['password'])){

      // fillter all $_GET input from link
        $email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_STRING);
        $password = md5(filter_input(INPUT_POST, 'password', FILTER_DEFAULT));

        // prepare query to know where email to verification
        $availability = mysqli_query($connect, "SELECT 1 FROM account WHERE email = '$email' LIMIT 1");
        if (mysqli_num_rows($availability) > 0) {
        
          // we store data into database//
          mysqli_query($connect, "UPDATE account SET password = '$password' WHERE email = '$email'");

          // redirect to home for login//
          header("refresh:1; url=home");
          echo "Password successfully changed, <b>Redirecting...</b>";
          echo "<meta http-equiv='refresh' content='2; url=../home'>";
          die;
        }
      } else {
        echo "Please fill in the required field";
        die;
      }
    } else {
      renderingLayout("reset");
      die;
    }
  } else {
    header("location:home");
    die;
  }
} else {
  header("location:dashboard");
  die;
}
?>
