-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2022 at 04:35 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roomfinder`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `phonenumber` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `live` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `register_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `user_name`, `email`, `password`, `gender`, `phonenumber`, `type`, `live`, `register_date`) VALUES
('SRF_614af7e', 'Bijan Acharya', 'acharyabijan129@gmail.com', '202cb962ac59075b964b07152d234b70', 'male', '9806595123', 'admin', '1', '2021-09-22 15:16:22'),
('SRF_6182019', 'Sujan Acharya', 'roomfinderchecker@gmail.com', '808179bd6e2b9eefbb0e161ad0ba1ca4', 'male', '9806595123', 'student', '1', '2021-11-03 09:12:20'),
('SRF_6243fd5b', 'Surya Gurung', 'bijan.acharya.a19@icp.edu.np', '202cb962ac59075b964b07152d234b70', 'male', '9806595123', 'owner', '1', '2022-03-30 12:34:05'),
('SRF_626782a7', 'Bijan Acharya', 'Acharyabijan021@gmail.com', '202cb962ac59075b964b07152d234b70', 'male', '9806595123', 'student', '1', '2022-04-26 11:12:09');

-- --------------------------------------------------------

--
-- Table structure for table `cclogs`
--

CREATE TABLE `cclogs` (
  `id` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fee` char(25) COLLATE utf8_unicode_ci NOT NULL,
  `PaymentBy` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `contact` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cclogs`
--

INSERT INTO `cclogs` (`id`, `owner`, `name`, `fee`, `PaymentBy`, `date`, `contact`) VALUES
('rsPaY__626789e265d42', 'Sujan Acharya', 'Terrace Room', '3000', 'Bijan Acharya', '2022-04-26 05:57:54.000000', 'roomfinderchecker@gmail.com'),
('rsPaY__62678caa9d8d6', 'Sujan Acharya', 'Apartment For a Family', '30000', 'Surya Gurung', '2022-04-26 06:09:46.000000', 'Acharyabijan021@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `name` varchar(25) NOT NULL,
  `message` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`name`, `message`, `time`) VALUES
('Rajan Poudel', 'Hello', '2022-04-25 04:20:49'),
('Bijan Acharya', 'Hello Guys!', '2022-04-26 01:59:58'),
('Bijan Acharya', 'Hello Guys', '2022-04-26 02:01:04'),
('Surya Gurung', 'Hello Sir', '2022-04-26 14:54:49');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `id` int(11) NOT NULL,
  `username` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sent_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`id`, `username`, `email`, `subject`, `sent_date`) VALUES
(1, 'Nabaraj Acharya', 'acharyabijan129@gmail.com', 'Hello Sir How can I help You?', '2022-03-22 06:23:35'),
(2, 'Ramesh Poudel', 'poudelramesh@gmail.com', 'Hello, Sir how can I change my password?', '2022-03-29 13:25:21'),
(3, 'Bijan Acharya', 'roomfinderchecker@gmail.com', 'Can you describe me more about this application?', '2022-04-02 13:16:24'),
(14, 'Ramesh Pant', 'rameshpant123@gmail.com', 'Hello Sir , How Can I upload my room ?', '2022-04-26 01:20:14');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fee` char(25) COLLATE utf8_unicode_ci NOT NULL,
  `categories` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `facilities` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `distance` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `images` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `roomowner` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `holder` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `name`, `fee`, `categories`, `description`, `address`, `facilities`, `distance`, `images`, `roomowner`, `holder`, `contact`, `status`, `uploaded_date`) VALUES
(80, 'Room For Single User', '2500', 'terrace house', 'Best Comfortabe room only fior single user', 'Pokhara', 'free wifi , hot water , fan', '1', 'room1.jpg', 'Sujan Acharya', 'roomfinderchecker@gmail.com', '9806595123', NULL, '2022-03-23 14:53:53'),
(81, 'Room At Pokhara', '3600', 'terrace house', 'The room I want to talk about is the living room. It’s pretty big, maybe the biggest room in the whole house. It’s shaped like a rectangle.', 'Pokhara-08, Srijanachowk', 'Spacious Private Parking Area,\r\nFree Wifi\r\n', '0.2', 'room4.jpg', 'Sujan Acharya', 'acharyabijan129@gmail.com', '9806595123', NULL, '2022-03-26 08:32:00'),
(83, 'Flat for 5 people', '12000', 'Flat', 'Flat for 5 people', 'Pokhara-08, Srijanachowk', 'Free Wifi', '1.4', 'room7.jpg', 'Sujan Acharya', 'acharyabijan129@gmail.com', '9806595123', NULL, '2022-03-26 09:26:04'),
(84, 'Terrace Room', '3000', 'terrace house', 'Terrace Room Only for 1 people', 'Pokhara-08, Srijanachowk', 'High Speed Internet , Hot Water', '1.9', 'room2.jpg', 'Sujan Acharya', 'roomfinderchecker@gmail.com', '9806595123', NULL, '2022-03-28 08:04:12'),
(85, 'Bunglaw In Pokhara', '25000', 'Bungalow', 'Bunglaw with beautiful scenario ', 'Lakeside , Pokhara', 'High Speed Internet , Hot Water , Attached Bathrooms, Spacious Parking Area', '0.5', 'room87.jpeg', 'Sujan Acharya', 'roomfinderchecker@gmail.com', '9806595123', NULL, '2022-03-28 08:07:55'),
(89, 'Single Room For 1 User', '3000', 'Duplex', 'Only For Single User', 'Pokhara', 'Free wifi , Hot water ', '0.9', 'room8.jpeg', 'Sujan Acharya', 'acharyabijan129@gmail.com', '9806595123', NULL, '2022-03-28 08:54:17'),
(90, 'Apartment For a Family', '30000', 'Service Apartment', 'Small Family Can Accept this apartment', 'Pokhara- 1, Bagar', 'High speed Internet, Hot Water, Solar ', '2.49', 'room4.jpg', 'Sujan Acharya', 'Acharyabijan021@gmail.com', '9806595123', NULL, '2022-03-28 09:20:56'),
(92, 'Room At Ranipauwa', '6000', 'Flat', 'Ranipauwa Flat', 'Pokhara-10, Ranipauwa', 'Free wifi', '1.88', 'room8.jpeg', 'Surya Gurung', 'bijan.acharya.a19@icp.edu.np', '9806595123', NULL, '2022-03-30 12:38:44'),
(93, 'Bagar Apartment', '25000', 'Townhouse Apartment', 'Apartment', 'Pokhara-1, Bagar', 'All Services', '1.44', 'room5455.jpg', 'Surya Gurung', 'bijan.acharya.a19@icp.edu.np', '9806595123', NULL, '2022-03-30 12:39:37'),
(94, 'Bunglaw At Lakeside', '50000', 'Bungalow', 'All Facilities', 'Pokhara-7 ,Lakeside', 'All ', '2.41', 'room5.jpg', 'Surya Gurung', 'bijan.acharya.a19@icp.edu.np', '9806595123', NULL, '2022-03-30 12:41:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`,`user_name`),
  ADD KEY `user_name` (`user_name`);

--
-- Indexes for table `cclogs`
--
ALTER TABLE `cclogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cc_holder` (`PaymentBy`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roomowner` (`roomowner`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cclogs`
--
ALTER TABLE `cclogs`
  ADD CONSTRAINT `cclogs_ibfk_1` FOREIGN KEY (`PaymentBy`) REFERENCES `account` (`user_name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`roomowner`) REFERENCES `account` (`user_name`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
