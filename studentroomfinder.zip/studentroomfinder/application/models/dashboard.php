<head>
      <script src="https://khalti.s3.ap-south-1.amazonaws.com/KPG/dist/2020.12.17.0.0.0/khalti-checkout.iffe.js"></script>
</head>
<nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="?">
    <!-- this show active session name and type account -->
    <?php echo strtoupper($_SESSION['account']['user_name'])  . "<sup class='badge badge-pill badge-danger'>". $_SESSION['account']['type'] ."</sup>"; ?>
  </a>

  <form action="" method="get" style="padding-left: 20px;
    width: 100%;
    ">
    <div class="input-group">
      <input type="text" name="search" class="form-control" value="" placeholder="Search Room Category or Room Type " autocomplete="off" required>
    </div>
  </form>

  <ul class="navbar-nav px-2">
    <li class="nav-item text-nowrap">
      <span style="cursor:pointer" class="btn btn-danger" onclick="window.open('?logout=session_destroy','_self');">Logout</span>
    </li>
  </ul>
</nav>
<div class="container-fluid">
  <div class="row">
    <nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link active" onclick="window.location.reload(false);" style="cursor: pointer;">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
              List Room
            </a>
          </li>

          <!-- this menu only show id type account as admin -->
          <?php
          if ($_SESSION['account']['type'] === 'admin') {
            print "
            <li class='nav-item'>
            <a class='nav-link' href='./content/show-list-user.php'>
            <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-users'>
            <path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'></path>
            <circle cx='9' cy='7' r='4'></circle>
            <path d='M23 21v-2a4 4 0 0 0-3-3.87'></path>
            <path d='M16 3.13a4 4 0 0 1 0 7.75'></path>
            </svg>
            List Account
            </a>
            </li>
            <li class='nav-item'>
            <a class='nav-link'href='./content/show-list-report.php'>
            <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-bar-chart-2'><line x1='18' y1='20' x2='18' y2='10'></line><line x1='12' y1='20' x2='12' y2='4'></line><line x1='6' y1='20' x2='6' y2='14'></line></svg>
            Reports
            </a>
            </li>
            <li class='nav-item'>
            <a class='nav-link' href='./content/show-enquiry-report.php'>
            <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-file-text'><path d='M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'></path><polyline points='14 2 14 8 20 8'></polyline><line x1='16' y1='13' x2='8' y2='13'></line><line x1='16' y1='17' x2='8' y2='17'></line><polyline points='10 9 9 9 8 9'></polyline></svg>
            View Enquiry
            </a>
            </li>
            ";
          }
          ?>

          <li class="nav-item">
            <a class="nav-link" href="./content/show-my-room.php">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers">
                <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                <polyline points="2 17 12 22 22 17"></polyline>
                <polyline points="2 12 12 17 22 12"></polyline>
              </svg>
              My Room
            </a>
          </li>

         
            <!-- <li class="nav-item">
              <a class="nav-link" href="./content/show-list-history.php">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bar-chart-2">
                  <line x1="18" y1="20" x2="18" y2="10"></line>
                  <line x1="12" y1="20" x2="12" y2="4"></line>
                  <line x1="6" y1="20" x2="6" y2="14"></line>
                </svg>
                History
              </a>
            </li> -->


            <?php
          if ($_SESSION['account']['type'] == 'student') {
            print "
            <li class='nav-item'>
            <a class='nav-link'href='./content/show-list-history.php'>
            <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-bar-chart-2'><line x1='18' y1='20' x2='18' y2='10'></line><line x1='12' y1='20' x2='12' y2='4'></line><line x1='6' y1='20' x2='6' y2='14'></line></svg>
            History
            </a>
            </li>
            ";
          }
          ?>


<?php
          if ($_SESSION['account']['type'] == 'owner') {
            print "
            <li class='nav-item'>
            <a class='nav-link'href='./content/show-list-history.php'>
            <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-bar-chart-2'><line x1='18' y1='20' x2='18' y2='10'></line><line x1='12' y1='20' x2='12' y2='4'></line><line x1='6' y1='20' x2='6' y2='14'></line></svg>
            History
            </a>
            </li>
            ";
          }
          ?>




           
           

          <li class="nav-item">
            <a class="nav-link" href="./content/show-edit-profile.php">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
              </svg>
              Edit Profile
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="./content/show-user-chat.php">            
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-message-circle">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
            </svg>
             Chat
            </a>
          </li>


          <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#submitRoomModal" style="cursor: pointer;">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="16"></line>
                <line x1="8" y1="12" x2="16" y2="12"></line>
              </svg>
              Submit Room
            </a>
          </li>
        </ul>
      </div>
    </nav>

    <!-- modal for sumbit room -->
    <div class="modal fade" id="submitRoomModal" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalCenterTitle">Submit Your Room</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form id="RoomForm" enctype="multipart/form-data">
              <div class="form-row mb-3">
                <div class="col">
                  <input type="text" name="name" class="form-control" placeholder="Room Name*" autocomplete="off" required>
                </div>
                <div class="col">
                  <input type="number" name="fee" class="form-control" placeholder="Rental Fee*" autocomplete="off" required>
                </div>
                <div class="col">
                  <select name="categories" class="form-control"required>
                    <option select>Categories*</option>
                    <option value="terrace house">terrace house</option>
                    <option value="Bungalow">Bungalow</option>
                    <option value="Detached Terrace">Detached Terrace</option>
                    <option value="link houses">link houses</option>
                    <option value="Townhouse Apartment">Townhouse Apartment</option>
                    <option value="Flat">Flat</option>
                    <option value="Condominium">Condominium</option>
                    <option value="Service Apartment">Service Apartment</option>
                    <option value="Residence">Residence</option>
                    <option value="Duplex">Stone House</option>

                  </select>
                </div>
              </div>
              <div class="form-row mb-3">
                <div class="col">
                  <input type="text" class="form-control" id="latitude" name="latitude" placeholder="Room address latitude*:"required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" id="longitude" name="longitude" placeholder="Room address longitude*:"required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" name="address" placeholder="Address*:"required>
                </div>
              </div>
              <div class="form-row mb-3">
                <div class="col">
                  <textarea class="form-control" rows="3" name="description" placeholder="Description*:"required></textarea>
                </div>
              </div>
              <div class="form-row mb-3">
                <div class="col">
                  <textarea class="form-control" rows="3" name="facilities" placeholder="Facilities*:"required></textarea>
                </div>
              </div>
              <div class="input-group mb-3">
                <div class="custom-file">
                  <input type="file" name="image" class="custom-file-input" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04">
                  <label class="custom-file-label" for="inputGroupFile04">Choose file</label>
                </div>
                <div class="input-group-append">
                  <button type="button" id="getLatlongitud" class="btn btn-warning">Get Current LatLongitude°</button>
                  <button type="submit" id="RoomButton" class="btn btn-primary">Submit Room</button>
                </div>
              </div>
            </form>
            <div id="RoomAlert" class="alert alert-dark mt-3 mb-3 mb-0">
              A simple danger alert—check it out!
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end modal -->

    

    <!-- main content dashboard -->
    <main class="col-md-12 ml-sm-auto col-lg-10 pt-3 px-4">

    <div class="btn-group btn-group-primary mb-2 mr-3">
        <label class="btn btn-secondary active">
          <a href="?nearest" style="color: white;">Suitable Rooms</a>
        </label>
        </div>

      <div class="btn-group btn-group-primary mb-2 mr-3">
        <label class="btn btn-secondary active">
          <a href="?latest" style="color: white;">Latest Rooms</a>
        </label>
        </div>
        <div class="btn-group btn-group-primary mb-2 mr-3">
        <label class="btn btn-secondary active">
          <a href="?nearby" style="color: white;">Nearby Rooms</a>
        </label> 
        </div>
        <div class="btn-group btn-group-primary mb-2 mr-3">
        <label class="btn btn-secondary active">
          <a href="?" style="color: white;">Low to High</a>
          </div>
        </label>
        <div class="btn-group btn-group-primary mb-2 mr-3">
        <label class="btn btn-secondary">
          <a href="?sort-by=expensive" style="color: white;">High to Low</a>
        </label> 
        </div>
        
      <div class="card-deck">
        <?php
        // defined connection to mysql
        $connect = new mysqli(host,name,pass,data);
       

        // NOTE: `fee`+0 MEAN convert the column to a numeric data type so we can sort them
       

        if (isset($_GET['sort-by'])) {
          $query = "SELECT * FROM room ORDER BY `fee`+0 DESC";
        } else {
          $query = "SELECT * FROM room ORDER BY `fee`+0 ASC";
        }

        if (isset($_GET['latest']))
				{
					$query = "SELECT * FROM room ORDER BY `uploaded_date`+0 DESC ";
        }
        
        if (isset($_GET['nearby']))
				{
					$query = "SELECT * FROM room ORDER BY `distance`+0 ASC ";
				}

        if (isset($_GET['nearest'])) {
          $query = "SELECT * FROM room where `distance`<'1' ";          
        }

        if (isset($_GET['search'])) {
          $keyword = $_GET['search'];
          $query = "SELECT * FROM room WHERE name LIKE '%$keyword%' OR categories LIKE '%$keyword%' OR facilities LIKE '%$keyword%' AND status ='NULL' ";
        }
        

        // $contact = $_SESSION['account']['contact'];
        // simple object-oriented interface mysqli to excute and fetch rows.
        // please see https://www.php.net/manual/en/mysqli.quickstart.dual-interface.php
        // loop the each row has fetch

        $result = $connect->query($query);
        while ($row = $result->fetch_assoc()) {
          if ($row['status'] == 1) {
            print "<div class='card mb-3' style='min-width: 18rem;display: none;'>";
          } else {
            print "<div class='card mb-3' style='min-width: 18rem;'>";
          }
          printf ("
          <div class='card-img-top' style='height: 230px;background: url(". dist . "upload/" . $row['images'] .");background-size: cover;background-position: center;'>
          <button type='button' class='btn btn-danger btn-sm' disabled>Owner: " .$row['roomowner']."</button>
          </div>
          <div class='card-body'>
          <h5 class='card-title'><strong> </strong>".$row['name']."</h5>
          <p class='card-text'><strong> </strong>".$row['description']."</p>
          </div>
          <ul class='list-group list-group-flush'>
          <li class='list-group-item'><strong>Room Rental: </strong>Rs. ".$row['fee']."</li>
          <li class='list-group-item'><strong>Address: </strong> ".$row['address']."</li>
          <li class='list-group-item'><strong>Category: </strong>".$row['categories']."</li>
          <li class='list-group-item'><strong>Facilities: </strong>".$row['facilities']."</li>
          <li class='list-group-item'><strong>Distance: </strong> <Strong>".$row['distance']."km</strong> from college</li>
          <li class='list-group-item'><strong>Contact</strong>: ".$row['contact']."</li>
          <li class='list-group-item'><strong>Posted on </strong>: ".$row['uploaded_date']." </li>
          </ul>
          
          <div class='card-body'>
          ".(($_SESSION['account']['type'] === 'admin')? "
          <a href='?id=".$row['id']."&table=room'class='card-link'' onClick=\"return confirm('Are you sure you want to delete this room ?')\"> <span class='btn btn-danger'>Delete Room</span></td>
          </a>
          ":"
          ".(($row['holder'] === $_SESSION['account']['email'])?
          "
          ":"
          <a href='payment.php?id=".$row['id']."&fee=".$row['fee']."&name=".$row['name']."&roomowner=".$row['roomowner']."&holder=".$row['holder']."' class='' return false;\">
          <span class='btn btn-primary' style='display: flex;align-items: center;'>
          Rent Room
          </span>
          </a>

          
          "
          )."
          ")."
          </div>

          
          </div>
        
          ");
      }



        ?>
      </div>
    </main>
  </div>
</div>

