
    <body class="home">
      <div class="text-center hero">

        <!-- modal contact Form -->
        <div class="modal fade" id="ContactModal" tabindex="-1">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" style="color:navy; text-align: center"><b>ENQUIRY</b></h5>
              </div>
              <div class="modal-body">
                <form id="ContactForm">
                  <div class="form-row mb-3">
                    <div class="col">
                      <input type="hidden" name="enquiry">
                      <input type="text" name="enquiry_name" class="form-control" placeholder="Full Name" autocomplete="off" required autofocus >
                    </div>
                  </div>
                  <div class="form-group mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email Address" autocomplete="on" required>
                  </div>
                  <div class="form-group">
                    <textarea name="message" class="form-control" placeholder="Type Your Message Here..." rows="3" maxlength="225" style="padding: 10px 15px;"></textarea>
                  </div>
                  <button type="submit" id="ContactButton" class="btn btn-primary btn-block">Send Message</button>
                  <div id="ContactAlert" class="alert alert-danger mt-4 mb-1">
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- end modal -->

       <!-- how it works -->
       <div class="modal fade" id="howModal" tabindex="-1">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title align-center"  ><font size="5" color="navy" ><b>How it Works</b></font></h5>
              </div>
              <div class="modal-body">
                <form id="howForm">
                  <div class="form-row mb-3">
                    <div class="col">
                        <ol>
                        <p><font size="4" color="black" > <b>For Student looking for a house</b></font></p>
                            <li><font size="3" color="black">Login with your newly created account</font></li>
                            <li><font size="3" color="black">Browse and search for your desired house</font></li>
                            <li><font size="3" color="black">Make a payment to rent the house and receive the payment digital slip in your Email.</font></li>
                        </ol>
                        <ol>
                        <p><font size="4" color="black"> <b>For Student or Owner looking for a User</b></font></p>
                            <li><font size="3" color="black">Login with your account</font></li>
                            <li><font size="3" color="black">Go to your Dashboard</font></li>
                            <li><font size="3" color="black">Upload your Room</font></li>
                        </ol>
                        <ol>
                        <p><font size="4" color="black"> <b>For New User</b></font></p>
                            <li><font size="3" color="black">Click on the register button on the Home page</font></li>
                            <li><font size="3" color="black">Enter your details</font></li>
                            <li><font size="3" color="black"> verify your newly created account.</font></li>
                            <li><font size="3" color="black"> Upon completion, log in using your newly created account.</font></li>
                        </ol>
                      </div>    
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      <!-- end modal -->

        <!-- modal Reset Form -->
        <div class="modal fade" id="ResetModal" tabindex="-1">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content py-5">
              <div class="modal-header">
                <h5 class="modal-title">Reset Your Account Password</h5>
              </div>
              <div class="modal-body">
                <form id="ResetForm">
                  <div class="form-group mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email Address" autocomplete="on" required>
                    <input type="hidden" name="ResetPassword">
                  </div>
                  <button id="ResetButton" type="submit" class="btn btn-primary btn-block">Reset Password</button>
                  <div id="ResetAlert" class="alert alert-dark mt-3">
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- end modal -->

        <!-- modal Login Form -->
        <div class="modal fade" id="LoginModal" tabindex="-1">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Login Your Account</h5>
              </div>
              <div class="modal-body">
                <form id="LoginForm">
                  <div class="form-group mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email Address" autocomplete="on" required/>
                  </div>
                  <div class="form-group mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Password" autocomplete="off" required/>
                  </div>
                  <button id="LoginButton" type="submit" class="btn btn-primary btn-block mb-2">Login</button>
                  </br> <a href="#" data-toggle="modal" data-target="#ResetModal"><center><strong><h5>Forgot password?</h5></strong></center></a>
                  <div id="LoginAlert" class="alert alert-danger mt-3">
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- end modal -->

        <!-- modal Register Form -->
        <div class="modal fade" id="RegisterModal" tabindex="-1">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Register Account</h5>
              </div>
              <div class="modal-body">
                <form id="RegisterForm">
                  <div class="form-row mb-3">
                    <div class="col">
                      <input type="text" name="user_name" class="form-control" placeholder="User Name" autocomplete="off" required>
                    </div>
                  </div>
                  <div class="form-group mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email Address" autocomplete="off" required >
                  </div>
                  <div class="form-group mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Password" autocomplete="off" required>
                  </div>

                  <div class="form-group mb-3">
                    <input type="re-password" name="re-password" class="form-control" placeholder="Re-Password" autocomplete="off" required>
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <label class="input-group-text" for="inputGroupSelect01">Gender</label>
                    </div>
                    <select name="gender" class="custom-select" id="inputGroupSelect01">
                      <option value="male" selected>Male</option>
                      <option value="female">Female</option>
                    </select>
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <label class="input-group-text" for="inputGroupSelect01">Account</label>
                    </div>
                    <select name="type" class="custom-select" id="inputGroupSelect01">
                      <option value="student" selected>student</option>
                      <option value="owner">house owner</option>
                    </select>
                  </div>
                  
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                  <select name="type" class="custom-select" id="inputGroupSelect01" disabled>
                  <option selected>(NP)+977</option>
              </select>
                </div>
               <div class="col">
              <input type="number" name="phonenumber" class="form-control" placeholder="phone number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" required>
            </div>
          </div>
                  <button type="submit" id="RegisterButton" class="btn btn-primary btn-block">Register</button>
                  <div id="RegisterAlert" class="alert alert-danger mt-3 mb-0">
                    A simple danger alert—check it out!
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- end modal -->

        <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
          <header class="masthead mb-auto">
            <div class="inner">
              <h4 class="masthead-brand" >
                <strong>STUDENT</strong>ROOM</strong>FINDER
              </h3>
              <nav class="nav nav-masthead justify-content-center">
                <a class="nav-link active" href="#">Home</a>           
                <a class="nav-link" href="#" data-toggle="modal" data-target="#ContactModal">Enquiry</a>
                <a class="nav-link" href="#" data-toggle="modal" data-target="#howModal">FAQ</a>
                <a class="nav-link" href="#" data-toggle="modal" data-target="#LoginModal">Sign In</a>
              </nav>
            </div>
          </header>

          <main class="inner cover">
            <h2 class="cover-heading focus">Looking for Student Accommodation</h2>
            <p class="lead">
              <a href="#" class="btn btn-lg btn-outline-light" data-toggle="modal" data-target="#RegisterModal">Register Now</a>
            </p>
          </main>

          <footer class="mastfoot mt-auto">
            <div class="inner">

            </div>
          </footer>
        </div>
      </div>
    </body>
