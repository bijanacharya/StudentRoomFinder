<nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="/">
    <!-- this show active session name and type account -->
    <?php echo $_SESSION['account']['user_name'] . "<sup class='badge badge-pill badge-danger'>". $_SESSION['account']['type'] ."</sup>"; ?>
  </a>
  <ul class=" navbar-nav px-3">
    <li class="nav-item text-nowrap">
      <button type="button" class="btn btn-danger">Logout</button>
    </li>
  </ul>
</nav>
<main class="py-4 px-4" style="display: flex;justify-content: center;align-items: center;height: 94vh;">
    <div class="card-deck">
      <?php
      print "
      <form id='ChangeRoomForm' class='card' style='min-width: 25rem;'>
        <div class='card-img-top' style='height: 160px;background: url(". dist . "upload/" . $_GET['images'] .");background-size: cover;background-position: center;'>
        </div>
        <div class='card-body'>
          <h5 class='card-title'><input type='text' name='name' class='form-control' placeholder='Name*' value='".$_GET['name']."' autocomplete='off' required></h5>
          <p class='card-text'><textarea class='form-control' id='exampleFormControlTextarea1' rows='3' name='description' placeholder='Description*:'>".$_GET['description']."</textarea></p>
        </div>
        <ul class='list-group list-group-flush'>
          <li class='list-group-item'><input type='number' name='fee' class='form-control' placeholder='Fee*' value='".$_GET['fee']."' autocomplete='off'></li>
          <li class='list-group-item'><textarea class='form-control' id='exampleFormControlTextarea1' rows='3' name='address' placeholder='Address*:'>".$_GET['address']."</textarea></li>
          <li class='list-group-item'>
            <select name='categories' class='form-control'>
              <option value='".$_GET['categories']."' select>".$_GET['categories']."</option>
              <option value='terrace house'>terrace house</option>
              <option value='Bungalow'>Bungalow</option>
              <option value='Detached Terrace'>Detached Terrace</option>
              <option value='link houses'>link houses</option>
              <option value='super link'>super link</option>
              <option value='Townhouse Apartment'>Townhouse Apartment</option>
              <option value='Flat'>Flat</option>
              <option value='Condominium'>Condominium</option>
              <option value='Service Apartment'>Service Apartment</option>
              <option value='Residence'>Residence</option>
              <option value='Duplex'>Duplex</option>
             
            </select>
          </li>
          <li class='list-group-item'><textarea class='form-control' id='exampleFormControlTextarea1' rows='3' name='facilities' placeholder='Facilities*:'>".$_GET['facilities']."</textarea></li>
        </ul>
        <div class='card-body'>
          <div class='btn-group'>
            <span class='card-link'>
              <button id='ChangeRoomButton' type='submit' class='btn btn-primary btn-block'>Update Room</button>
            </span>
            <a href='../dashboard/' class='card-link'>
              <span class='btn btn-danger'>Cancel Editing</span>
            </a>
          </div>
          <div id='ChangeRoomAlert' class='alert alert-dark mt-3'>
          </div>
        </div>
      </div>
      ";
      ?>
    </div>
</main>
