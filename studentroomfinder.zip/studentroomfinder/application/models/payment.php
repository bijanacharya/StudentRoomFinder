<head>
<script src="https://khalti.s3.ap-south-1.amazonaws.com/KPG/dist/2020.12.17.0.0.0/khalti-checkout.iffe.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>

<main id="payment"  style="background-color: white;">
  
  <form id="PaymentForm">
  
    <div class="form-header mb-5" style="background-color: azure;">
      <h1>Payment With Khalti</h1>
      <img src="<?php echo dist . "/image/room.jpg"; ?>" class="img-fluid">
    
      <h5 class="mt-5">Payment for <strong><?php echo $_GET['name']; ?></strong></h5>
      <h5 class="mt-5">Fee : Rs.  <?php echo $_GET['fee']; ?></h5>
      <h5 class="mt-5">Room Owner : <?php echo $_GET['roomowner']; ?></h5>
      <!-- <h5 class="mt-5">Address : <?php echo $_GET['address']; ?></h5> -->
      <h5 class="mt-5">Email  : <?php echo $_GET['holder'];?></h5>
    </div>
    <div class="form-group" style="display: none;">
      <input type="text" name="Phone_Number" class="form-control" pattern="\d*" maxlength="16" placeholder="Phone Number" autocomplete="off">
    </div>

    <div class="form-group" style="display: none;">
      <input type="text" name="Password" class="form-control" pattern="\d*" maxlength="16" placeholder="Password" autocomplete="off">
    </div>


    <div class="form-group">
      <input type="text" name="acc_holder" class="form-control" value="<?php echo $_SESSION['account']['user_name']; ?>" placeholder="Holder Name" autocomplete="off" disabled>
    </div>
    
<!-- 
    <button id="PaymentButton" type="submit" class="btn btn-primary btn-block">Pay Rs.<?php echo $_GET['fee']; ?>*</button> -->

    <!-- Place this where you need payment button -->
    <button   class="btn btn-primary btn-block"  id="payment-button">Continue Payment<strong> Rs. <?php echo $_GET['fee']; ?></strong></button>
    <!-- Place this where you need payment button -->
    <!-- Paste this code anywhere in you body tag -->
    <script>
        var config = {
            // replace the publicKey with yours
            "publicKey": "test_public_key_3f2bf67a883e44c6b080c7f91faa41ea",
            "productIdentity": "9806595123",
            "productName": "Dragon",
            "productUrl": "http://gameofthrones.wikia.com/wiki/Dragons",
            "paymentPreference": [
                "KHALTI",
                "EBANKING",
                "MOBILE_BANKING",
                "CONNECT_IPS",
                "SCT",
                ],
            "eventHandler": {
                onSuccess (payload) {
                    // hit merchant api for initiating verfication
                    console.log(payload);
                },
                onError (error) {
                    console.log(error);
                    
                },
                onClose () {
                    console.log('widget is closing');
                }
            }
        };

        var checkout = new KhaltiCheckout(config);
        var btn = document.getElementById("payment-button");
        btn.onclick = function () {
            // minimum transaction amount must be 10, i.e 1000 in paisa.
            checkout.show({amount: <?php echo $_GET['fee']; ?>});
            swal("Success", "Success");
            //window.location = '../dashboard';
        
            
        }
        
     
    </script>
    <!-- Paste this code anywhere in you body tag -->
    
    
  </form>

  

</main>
