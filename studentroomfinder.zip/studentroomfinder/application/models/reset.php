<div style="
    display: grid;
    max-width: 350px;
    margin: 0 auto;
    height: 100vh;
    align-items: center;
    ">
  <div class="container">
    <form id="ResetForm">
     
      <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
              
      <Label> <h3> <strong> Reset Password </strong> </h3>
      <div class="form-group mb-3">
      <input style="margin-bottom: 20px;" type="password" name="password" class="form-control" placeholder="New Password" autocomplete="off"required>
      <input style="margin-bottom: 20px;" type="re-password" name="re-password" class="form-control" placeholder="Re-New Password" autocomplete="off"required>
      </div>
      <button type="submit" id="ResetButton" class="btn btn-primary btn-block">Continue</button>
      <div id="ResetAlert" class="alert alert-dark mt-3 mb-0">
      </div>
    </form>
  </div>
</div>
