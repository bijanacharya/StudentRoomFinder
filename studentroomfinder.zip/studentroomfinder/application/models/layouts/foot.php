 <!-- script -->
 <script src="<?php echo dist . "jquery-3.4.1.min.js"; ?>"></script>
  <script src="<?php echo dist . "main.js"; ?>"></script>
  <script src="<?php echo dist . "bootstrap-4.3.1/js/bootstrap.min.js"; ?>"></script>
  <script src="<?php echo dist . "bootstrap-4.3.1/js/bootstrap.bundle.min.js"; ?>"></script>
</html>
