<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <!-- style -->
    <link rel="stylesheet" href="<?php echo dist . "bootstrap-4.3.1/css/bootstrap.min.css"; ?>">
    <link rel="stylesheet" href="<?php echo dist . "bootstrap-4.3.1/css/bootstrap-grid.min.css"; ?>">
    <link rel="stylesheet" href="<?php echo dist . "bootstrap-4.3.1/css/bootstrap-reboot.min.css"; ?>">
    <link rel="stylesheet" href="<?php echo dist . "master.css"; ?>">
  </head>
