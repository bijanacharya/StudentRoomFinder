<?php
session_start();

// defined mysql connection
define('host', 'localhost');
define('name', 'root');
define('pass', '');
define('data', 'roomfinder');

// defined PHPMailer connection smtp for gmail
define('SMTPhost', 'smtp.gmail.com');
define('SMTPport', '587');
define('SMTPuser', 'roomfinderchecker@gmail.com');
define('SMTPpass', 'roomfinderchecker@123');

// defined base.path, controller, models and distribution assets.
// all control and file in directory application path was define here,
// so no need call full path directory every time we need.
define('base', '/application' . "/");
define('ctrl', dirname(__DIR__, 2) . base . 'controller/');
define('mode', dirname(__DIR__, 2) . base . 'models/');
define('dist', '..' . base . 'src/dist/');

// define html layouts
// just define full path directory the file.
define('head', mode . 'layouts/head.php');
define('foot', mode . 'layouts/foot.php');

// define latitude and longitude the college
// you can get it from google mpas and other
define('latitude', '28.196864');
define('longitude', '83.9745536');

// included the object.
// this function make object included
function buffering($name)
{
  ob_start();
  include_once($name);
  return ob_get_clean();
}

// print the included object.
// after object was included on function buffering
// we must print (render) the content object to browser.
// this function make we no need write or include <html> every page
function renderingLayout($value)
{
  print buffering(head);
  print buffering(mode . $value . ".php");
  print buffering(foot);
}

// MySQLi_connect objected oriented interface style
// this will make us no longer need connect to MySQLi every page.
$connect = new mysqli(host,name,pass,data);
?>
