<?php
require_once dirname(__DIR__) . '/application/src/autoload.php';
require_once dirname(__DIR__) . '/application/src/PHPMailer-5.2.27/PHPMailerAutoload.php';

if (empty($_SESSION['account'])) {

  // this if condition useful for checking whether there are any posts
  // if not we will immediately display the html layout and model
  if (!empty($_POST)) {

      // fillter all post from ajax
      $enquiryusername = filter_input(INPUT_POST, 'enquiry_name', FILTER_SANITIZE_STRING);
      $username = filter_input(INPUT_POST, 'user_name', FILTER_SANITIZE_STRING);
      $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);
      $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
      $type = filter_input(INPUT_POST, 'type', FILTER_SANITIZE_STRING);
      $password = md5(filter_input(INPUT_POST, 'password', FILTER_DEFAULT));
      $gender = filter_input(INPUT_POST, 'gender', FILTER_SANITIZE_STRING);
      $phonenumber =filter_input(INPUT_POST, 'phonenumber', FILTER_SANITIZE_STRING);
      $id = uniqid('SRF_');

    // validate email format
    if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {

      // if ajax submit post 'enquiry' we recognize it as a 'enquiry form'
        if (isset($_POST['enquiry'])) {
          mysqli_query($connect, "INSERT INTO enquiry (username, email, subject, sent_date) VALUES ('$enquiryusername','$email','$message',NOW())");
          header("refresh:1; url=home");
          echo "Your Enquiry is sent Successfully!";
          echo "<meta http-equiv='refresh' content='2; url=../home'>";        
          die;
        }
  

      // if ajax submit post 'ResetPassword' we recognize it as a 'reset password form'
      if (isset($_POST['ResetPassword'])) {
        // check whether the email has been used or not
        $availability = mysqli_query($connect, "SELECT 1 FROM account WHERE email = '$email' LIMIT 1");
        if (mysqli_num_rows($availability) == 1) {

          // PHPMailer class and gmail smtp data & info
          $PHPMailer = new PHPMailer;
          $PHPMailer->IsSMTP();
          $PHPMailer->Host = SMTPhost;
          $PHPMailer->SMTPAuth = true;
          $PHPMailer->SMTPSecure = 'tls';
          $PHPMailer->Port = SMTPport;
          $PHPMailer->Username = SMTPuser;
          $PHPMailer->Password = SMTPpass;

          // content email to send
          $PHPMailer->setFrom(SMTPuser, "noreply@studentroom");
          $PHPMailer->AddAddress("$email" , "$username");
          $PHPMailer->isHTML(true);
          $PHPMailer->Subject = "Studentroom Reset Password";

          // html was minifier by minifycode.com
          $uri = "http://localhost" . dirname($_SERVER['REQUEST_URI'])."/reset/?email=".$email."&token_reset=".base64_encode($email);
          $html = '
          <!DOCTYPE html>
          <html lang="en" dir="ltr">
          <head>
          <meta charset="utf-8">
          <title>Reset Your Password</title>
          </head>
          <body style="background: #f4f7fa;padding: 100px 0;font-family: -apple-system,BlinkMacSystemFont,&#39;Segoe UI&#39;,&#39;Roboto&#39;,&#39;Oxygen&#39;,&#39;Ubuntu&#39;,&#39;Cantarell&#39;,&#39;Fira Sans&#39;,&#39;Droid Sans&#39;,&#39;Helvetica Neue&#39;,sans-serif;">
          <table cellpadding="0" width="600" cellspacing="0" border="0" style="text-align: center;margin: 0 auto;padding: 40px 100px;background: #ffff;border-radius: 5px;">
          <tr>
          <td style="padding-bottom: 40px;"> <img alt="Coinbase" width="80" src="https://www.coinbase.com/assets/app/icon_email-e8c6b940e8f3ec61dcd56b60c27daed1a6f8b169d73d9e79b8999ff54092a111.png"></td>
          </tr>
          <tr>
          <td style="color:#48545d;font-size:22px;padding-bottom: 20px;border-bottom: 1px solid #dae1e9;">Reset Your Password</td>
          </tr>
          <tr>
          <td><a href="'.$uri.'" style="display:block;padding:15px 25px;background-color:#0087D1; color:#ffffff;border-radius:3px;text-decoration:none;">Reset Password</a></td>
          </tr>
          </table>
          </body>
          </html>
          ';
          $PHPMailer->Body = $html;

          // if the mail reset was send
          if ($PHPMailer->Send()) {
            echo "Password reset link successfully sent";
            die;
          } else {
            echo "Failed to send email, please contact admin !";
            die;
          }
        } else {
          echo "Sorry This Email is not registered in our system!!";
          die;
        }
      }

      // if ajax submit post 'type' we recognize it as a 'registration form'
      // cus login form no need post type.
      if (isset($_POST['type'])) {
        // check if any field are empty 
        if (!empty($_POST['user_name']) && !empty($_POST['email']) &&!empty($_POST['password'])&&!empty($_POST['gender'])&&!empty($_POST['phonenumber'])&&!empty($_POST['type'])){
         
          if (!filter_var($_POST['user_name'], FILTER_VALIDATE_EMAIL)){ //email cant be used in username    
        
            // check whether the email has been used or not
            $availability = mysqli_query($connect, "SELECT 1 FROM account WHERE email = '$email' LIMIT 1");

            if (mysqli_num_rows($availability) == 0) {

              // PHPMailer class and gmail smtp data & info
              $PHPMailer = new PHPMailer;
              $PHPMailer->IsSMTP();
              $PHPMailer->Host = SMTPhost;
              $PHPMailer->SMTPAuth = true;
              $PHPMailer->SMTPSecure = 'tls';
              $PHPMailer->Port = SMTPport;
              $PHPMailer->Username = SMTPuser;
              $PHPMailer->Password = SMTPpass;

              // content email to send
              $PHPMailer->setFrom(SMTPuser, "noreply@studentroom");
              $PHPMailer->AddAddress("$email" , "$username");
              $PHPMailer->isHTML(true);
              $PHPMailer->Subject = "Studentroom Email Verification";

              // html was minifier by minifycode.com
              $uri = "http://localhost/" . dirname($_SERVER['REQUEST_URI'])."/?email=".$email."&verification=".base64_encode($password);
              $html = '
              <!DOCTYPE html>
              <html lang="en" dir="ltr">
              <head>
              <meta charset="utf-8">
              <title>Please Verify Your Email Address</title>
              </head>
              <body style="background: #f4f7fa;padding: 100px 0;font-family: -apple-system,BlinkMacSystemFont,&#39;Segoe UI&#39;,&#39;Roboto&#39;,&#39;Oxygen&#39;,&#39;Ubuntu&#39;,&#39;Cantarell&#39;,&#39;Fira Sans&#39;,&#39;Droid Sans&#39;,&#39;Helvetica Neue&#39;,sans-serif;">
              <table cellpadding="0" width="600" cellspacing="0" border="0" style="text-align: center;margin: 0 auto;padding: 40px 100px;background: #ffff;border-radius: 5px;">
              <tr>
              <td style="padding-bottom: 40px;"> <img alt="Coinbase" width="80" src="https://www.coinbase.com/assets/app/icon_email-e8c6b940e8f3ec61dcd56b60c27daed1a6f8b169d73d9e79b8999ff54092a111.png"></td>
              </tr>
              <tr>
              <td style="color:#48545d;font-size:22px;padding-bottom: 20px;border-bottom: 1px solid #dae1e9;">Verify your email address</td>
              </tr>
              <tr>
              <td style="color:#48545d;font-size:14px;padding: 20px 0;">You’re nearly there!
              Hi   <strong>'.$username.'</strong>, 
              To finish setting up your account and start using studentroomfinder, confirm we’ve got the correct email for you.</td>
              </tr>
              <tr>
              <td><a href="'.$uri.'" style="display:block;padding:15px 25px;background-color:#0087D1; color:#ffffff;border-radius:3px;text-decoration:none;">Verify Email Address</a></td>
              </tr>
              </table>
              </body>
              </html>
              ';
              $PHPMailer->Body = $html;

              // if the mail verification was send
              // we store data into database
              if ($PHPMailer->Send()) {
                mysqli_query($connect, "INSERT INTO account (id,user_name,email,password,gender,phonenumber,type,register_date) VALUES ('$id','$username','$email','$password','$gender','$phonenumber','$type',NOW())");
                echo "<b>Account has been registered</b>, verify your email";
                die;
              } else {
                echo "Failed to send email, please contact admin !";
                die;
              }
            } else {
              echo "Sorry This Email is already in use";
              die;
            }
          } else{
            echo "You can't use email as username!";
            die;
          }
        } else {
          echo "Please fill in the all required field!";
          die;
        }
      } elseif (!isset($_POST['type'])) {

        // conditions above it's for know if(the submit $_POST not contain post 'tpye')
        // so we know it as login type. and now try to know address email for login
        $result = mysqli_query($connect, "SELECT * FROM account WHERE email = '$email' LIMIT 1");
        if (mysqli_num_rows($result) > 0) {

          // fetch data from query
          while ($rows = mysqli_fetch_array($result)) {

            // we will check email all ready verify or not
            if ($rows['live'] == true) {

              // verify the password
              if ($rows['password'] === $password) {

                // unset password from session, cus we dont need this
                // and store all data fetch to session
                unset($rows['password']);
                $_SESSION['account'] = $rows;
                die;
              } else {
                echo "Incorrect password please try again";
                die;
              }
            } else {
              echo "please verify email to continue logging in";
              die;
            }
          }
        } else {
          echo "Email does not match any account";
          die;
        }
      }
    } else {
      echo "Invalid email address";
      die;
    }
  } else {
    renderingLayout("home");
    die;
  }
} else {
  header("location:../dashboard/");
  exit;
}
?>
