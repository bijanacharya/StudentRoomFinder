<section id="about">
    
    <div class="container">
    	<div class="row">
    		<div class="col-md-12">
    		<br>
    		<h2 align="center">How it Works</h2>
   			 <hr>    
    			<div class="col-md-6">
                <ol>
                	<p><i><b>For Student looking for a Room</b></i></p>
                    <li>Login with your newly created account</li>
                    <li>Browse and search for your desired house</li> 
                    <li>Contact the number provided in the details if you find your desired house</li>    
                </ol>
                </div>
                
                <div class="col-md-6">
                <ol>
                	<p><i><b>For Student or Owner looking for a tenant</b></i></p>
                    <li>Login with your account</li>
                    <li>Go to your Submit Room page</li>
                    <li>Upload your Room</li>
                 </ol>
                </div>
                
                <div class="col-md-6">
                <ol>
                	<p><i><b>For New User</b></i></p>
                    <li>Click on the register link on the home page</li>
                    <li>Enter your details</li>
                    <li>Upon completion, log in using your newly created account.</li>
                 </ol>
                </div>
    		</div>
    	</div>
    </div>    
    </section><br>