<?php
require_once __DIR__ . '/application/src/autoload.php'; 

// session checking, if no set, we will continue to home
// if has been set, we will redirect to dashboard
if (empty($_SESSION['account'])) {

  // if user click verify email, the link redirecting to here
  // with $_GET information about email & verification code;
  // so we direct are link have $_GET method or not
  if (isset($_GET['email'])) {

    // fillter all $_GET input from link
    $email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_GET, 'verification', FILTER_DEFAULT);

    // prepare query to know where email to verification
    $availability = mysqli_query($connect, "SELECT * FROM account WHERE email = '$email' LIMIT 1");
    if (mysqli_num_rows($availability) > 0) {

      // we fetch all data from selected email
      $rows = mysqli_fetch_assoc($availability);

      // if data 'live' it's null we will continue
      // this make sure email all ready verify or not
      if ($rows['live'] == NULL) {

        // compare data password with $_GET decodeing verification
        if ($rows['password'] === base64_decode($password)) {

          // continue update data 'live' to 1 for know it was verify
          mysqli_query($connect, "UPDATE account SET live = '1' WHERE email = '$email';");

          // redirect to home for login
          echo "Email successfully verified, <b>Redirecting...</b>";
          header("Refresh:3; url=home");
          die;
        } else {
          echo " verification code is not same";
          die;
        }
      } else {
        echo "link expired or email has been verified already";
        die;
      }
    } else {
      echo "Couldn't find the verification email address";
      die;
    }
  } else {
    header("location:home");
    die;
  }
} else {
  header("location:dashboard");
  die;
}
?>
