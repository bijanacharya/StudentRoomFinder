<!DOCTYPE html>
<html lang="en">

<head>
  <?php  include_once '../../application/src/autoload.php';?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!-- <script src="../../Jquery/prettify.js"></script> -->
    <title>Login</title>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>
</head>
<body>
<div class="table-responsive">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th>User Name</th>
        <th>Message</th>
        <th>Time</th>

      </tr>
    </thead>
    <tbody>
      <?php
      include_once '../../application/src/autoload.php';
      if ($result = $connect->query("SELECT * FROM chat ORDER BY time DESC")) {
        while ($row = $result->fetch_assoc()) {
          printf("
        <tr>
        <td>" . $row['name'] . "</td>
        <td>" . $row['message'] . "</td>
        <td>".$row['time']."</td>
     
          </tr>
          ");
        }
      }

      
      ?>

      


    </tbody>
  </table>


</div>


<?php require_once dirname(__DIR__) . '../../application/src/autoload.php'; ?>

<div class="modal-content">
  <div class="modal-header">
    <h5 class="modal-title" style="color:navy; text-align: center"><b>Your Message</b></h5>
  </div>
  <div class="modal-body">
    <form class ="form-floating mb-3 mt-3" id="message-form">

    <div class="form-group">
      <input type="text"  id = "name" name="name" class="form-control" value="<?php echo $_SESSION['account']['user_name']; ?>" placeholder="" autocomplete="off" disabled>
    </div>
<!-- 
    <div class="form-group">
      <input type="text"  id = "time" name="time" class="form-control" value="<?php echo " "  . date("Y-m-d") ." ". date("h:i:sa"); ?>" placeholder="" autocomplete="off" disabled>
    </div> -->
      <div class="form-group" >
        <textarea name="message" id = "message" class="form-control" placeholder="Type Your Message Here..." rows="3" maxlength="1000" style="padding: 10px 15px;" required></textarea>
      </div>
      <button type="button" class="btn btn-primary btn-block" onclick="sendMsg()" value="
      Send Message"  >Send Message</button>
      <div id="MessageAlert" class="alert alert-danger mt-4 mb-1">
      </div>
    </form>
  </div>
  </div>

<script>


  

  function sendMsg(){
    
    var name = document.getElementById('name').value;
        var message = document.getElementById('message').value;
        // var time = document.getElementById('time').value;
      
        //echo(name,message);

       // alert("hsh");
        ajaxCall(name,message);

  


        

    }



    function ajaxCall(name, message,time) {
        var xhttp;
        xhttp = new XMLHttpRequest();
        xhttp.open("POST", "content/insert.php");
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("name=" + name + "&message=" + message +"");
        xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {
              
              
               swal("Success", "Message Successfully Sent");
               document.getElementById('message').value= "";
               document.getElementById('message-form').reload();

      
        
               

            }

        };
        

    }


      
    </script>

  </body>
</html>



