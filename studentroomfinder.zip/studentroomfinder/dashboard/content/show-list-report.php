<div class="table-responsive">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
       <th>Payment ID</th>
        <th>Room Name</th>
        <th>Owner</th>
        <th>Payment By</th>
        <th>Payment Date</th>
        <th>Fee</th>
        <th>Contact</th>
      </tr>
    </thead>
    <tbody>
      <?php
      include_once '../../application/src/autoload.php';
      if ($result = $connect->query("SELECT * FROM cclogs ORDER BY id ASC")) {
        while ($row = $result->fetch_assoc()) {
          printf ("
          <tr>
            <td>".$row['id']."</td>
            <td>".$row['name']."</td>
            <td>".$row['owner']."</td>
            <td>".$row['PaymentBy']."</td>
            <td>".$row['date']."</td>
            <td>"."<strong>Rs. </strong>".$row['fee']."</td>
            <td>".$row['contact']."</td>
            <td><a href='?id=".$row['id']."&table=cclogs'\" onClick=\"return confirm('Are you sure you want to delete this Record?')\">Remove</a></td>
          </tr>
          ");
        }
      }
      ?>
    </tbody>
  </table>
</div>
