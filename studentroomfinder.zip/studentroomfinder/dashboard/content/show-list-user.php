<!-- Users List -->
<div class="table-responsive">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
      <th>User ID</th>
        <th>User Name</th>
        <th>Email</th>
        <th>Contact number</th>
        <th>Gender</th>
        <th>Type</th>
        <th>Registered date</th>
        <th>Verification</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      include_once '../../application/src/autoload.php';
      if ($result = $connect->query("SELECT * FROM account ORDER BY id DESC")) {
        while ($row = $result->fetch_assoc()) {
          printf ("
          <tr>
          <td>".$row['id']."</td>
          <td>".$row['user_name']."</td>
          <td>".$row['email']."</td>
          <td>".$row['phonenumber']."</td>
          <td>".$row['gender']."</td>
          <td>".$row['type']."</td>
          <td>".$row['register_date']."</td>
            <td>".(($row['live'] === '1')? "verified":"not yet")."</td>
            <td> <a href='?id=".$row['id']."&table=account'\" onClick=\"return confirm('Are you sure you want to delete this user account?')\">Remove user </a></td>
          </tr>
          ");
        }
      }
      ?>
    </tbody>
  </table>
</div>
