<div class="table-responsive">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Date</th>
        <th>Message</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      include_once '../../application/src/autoload.php';
      if ($result = $connect->query("SELECT * FROM enquiry ORDER BY id DESC")) {
        while ($row = $result->fetch_assoc()) {
          printf ("
          <tr>
            <td>".$row['username']."</td>
            <td>".$row['email']."</td>
            <td>".$row['sent_date']."</td>
            <td>".$row['subject']."</td>
            <td><a href='?id=".$row['id']."&table=enquiry'\" onClick=\"return confirm('Are you sure you want to delete this user Enquiry?')\">Remove Enquiry </a></td>
          </tr>
          ");
        }
      }
      ?>
    </tbody>
  </table>
</div>
<!-- <td><a class='nav-link' href='#' data-toggle='modal' data-target='#ContactModal'>Reply</a></td> -->