<html>
  <head>

  

  </head>


<?php
 include_once '../../application/src/autoload.php';


$name=$_POST['name'];
$message=$_POST['message'];


$query="INSERT INTO `chat` (`name`, `message`) VALUES ('$name', '$message');";


$result = $connect->query($query);
 

echo 'true';




?>

</html>