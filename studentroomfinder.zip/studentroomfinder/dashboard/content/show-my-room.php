<div class="card-deck">
  <?php
  include_once '../../application/src/autoload.php';

  // define contact as session email,
  // this make my room just swho only user upload, not global upload
  // so we just ordered by uploader email
  $contact = $_SESSION['account']['email'];

  // simple object-oriented interface mysqli to excute and fetch rows.
  // please see https://www.php.net/manual/en/mysqli.quickstart.dual-interface.php
  if ($result = $connect->query("SELECT * FROM room WHERE holder = '$contact' ORDER BY id DESC")) {

    // loop the each row has fetch
    while ($row = $result->fetch_assoc()) {
      printf ("
      <div class='card mb-3' style='min-width: 18rem;'>
        <div class='card-img-top' style='height: 220px;background: url(". dist . "upload/" . $row['images'] .");background-size: cover;background-position: center;'>
        ".(($row['status'] === '1')?"<button type='button' class='btn btn-success btn-sm' disabled>Rented</button>":"")."
        </div>
          <div class='card-body'>
          <h5 class='card-title'>".$row['name']."</h5>
          <p class='card-text'>".$row['description']."</p>
        </div>
        <ul class='list-group list-group-flush'>
          <li class='list-group-item'>Rent Price <strong>: Rs. ".$row['fee']."</strong></li>
          <li class='list-group-item'>Location : ".$row['address']."</li>
          <li class='list-group-item'>Category : ".$row['categories']."</li>
          <li class='list-group-item'>Facilities : ".$row['facilities']."</li>
          <li class='list-group-item'>Distance : <strong>".$row['distance']."</strong> Km from College</li>
          <li class='list-group-item'><strong>Posted on</strong>: ".$row['uploaded_date']." </li>
        </ul>
        <div class='card-body'>
          <div class='btn-group'>
            ".(($row['status'] === NULL)?
            "
            <a href='change.php?id=".$row['id']."&images=".$row['images']."&name=".$row['name']."&description=".$row['description']."&fee=".$row['fee']."&address=".$row['address']."&categories=".$row['categories']."&facilities=".$row['facilities']."' class='card-link'>
              <button type='button' class='btn btn-secondary btn-block'>Edit Room</button>
            </a>
            ":"
            <a href='#' class='card-link'>
              <button type='button' class='btn btn-secondary btn-block' disabled>Edit Room</button>
            </a>
            "
            )."
            <a href='?id=".$row['id']."&table=room' class='card-link'' onClick=\"return confirm('Are you sure you want to delete this room ?')\"> <span class='btn btn-danger'>Delete Room</span></td> 
              
            </a>
          </div>
        </div>
      </div>
      ");
    }
  }
  ?>
</div>
