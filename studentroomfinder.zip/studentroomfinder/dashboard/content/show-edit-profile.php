<?php require_once dirname(__DIR__) . '../../application/src/autoload.php'; ?>
<div class="container">
  <form id="RegisterForm" action="" method="post">
    <div class="form-row mb-3">
      <div class="col">
        <input type="hidden" name="edit_profile">
        <input type="text" name="user_name" class="form-control" placeholder="username" autocomplete="off" value="<?php echo $_SESSION['account']['user_name']; ?>"required autofocus >
      </div>
    </div>
    <div class="form-group mb-3">
      <input type="email" name="email" class="form-control" placeholder="Email address" autocomplete="off" value="<?php echo $_SESSION['account']['email']; ?>" disabled required>
    </div>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <label class="input-group-text" for="inputGroupSelect01">Accounts</label>
      </div>
      <select name="type" class="custom-select" id="inputGroupSelect01" disabled>
        <option value="<?php echo $_SESSION['account']['type']; ?>" selected><?php echo $_SESSION['account']['type']; ?></option>
      </select>
    </div>
    <div class="form-group mb-3">
      <input type="password" name="password" class="form-control" placeholder="New Password" autocomplete="off" required>
    </div>
    <div class="form-group mb-3">
      <input type="password" name="re password" class="form-control" placeholder="Re - New Password" autocomplete="off" required>
    </div>
    <div class="form-group mb-3">
    <input type="number" name="phonenumber" class="form-control" placeholder="Phone number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "11" autocomplete="off">
    </div>
    <button type="submit" id="Register-Button" class="btn btn-primary btn-block">submit</button>
    <div id="RegisterAlert" class="alert alert-danger mt-3 mb-0">
    </div>
  </form>
</div>
