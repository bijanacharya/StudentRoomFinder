<?php
require_once dirname(__DIR__) . '/application/src/autoload.php';
require_once dirname(__DIR__) . '/application/src/PHPMailer-5.2.27/PHPMailerAutoload.php';

// session checking, if no set, we will continue to home
// if not set yet, we point to the home
if (isset($_SESSION['account'])) {

  // if payment.php have id= parameter on url
  // we know as legitimate payment. if not, we immediately close the window payment popup
  if (!empty($_GET['id'])) {

    // this if condition useful for checking whether there are any posts
    // if not we will immediately display the html layout and model
    if (!empty($_POST)) {

     



     

         // execute the $query to database
      // if (!empty($_POST['acc_holder'])) {

        // define and filtered post
        $id = $_GET['id'];
        $owner = $_GET['roomowner'];
        $name = $_GET['name'];
        $fee = $_GET['fee'];
        $acc_holder = $_SESSION['account']['user_name'];
        $contact = $_GET['holder'];
        $payid = uniqid('rsPaY__');
        $query="INSERT INTO `cclogs` (`id`, `owner`, `name`, `fee`, `PaymentBy`, `date`, `contact`) VALUES ( '$payid', '$owner', '$name','$fee' ,'$acc_holder', NOW(), '$contact');";


        if (mysqli_query($connect, $query)) {
          $query = " UPDATE room
          SET status = '1'
          WHERE id = $id;
          ";
          if (mysqli_query($connect, $query)) {
            
           
        
          }

         
         
        }
        else{
          echo"<script>alert('Unsuccess Payment!');window.location = '../dashboard';</script>";
        }

        // PHPMailer class and gmail smtp data & info
        $PHPMailer = new PHPMailer;
        $PHPMailer->IsSMTP();
        $PHPMailer->Host = SMTPhost;
        $PHPMailer->SMTPAuth = true;
        $PHPMailer->SMTPSecure = 'tls';
        $PHPMailer->Port = SMTPport;
        $PHPMailer->Username = SMTPuser;
        $PHPMailer->Password = SMTPpass;

        // content email to send
        $datetime = new DateTime('NOW', new DateTimeZone('Asia/Kathmandu'));
        $PHPMailer->setFrom(SMTPuser, "noreply@studentroom");
        $PHPMailer->AddAddress("$contact" , "$acc_holder");
        $PHPMailer->isHTML(true);
        $PHPMailer->Subject = "Payment for room $name";
        $html = '<!DOCTYPE html>
        <html lang="en" dir="ltr">
        <head>
        <meta charset="utf-8">
        <title>Payment Successful</title>
        </head>
        <body style="background: #f4f7fa;padding: 100px 0;font-family: -apple-system,BlinkMacSystemFont,&#39;Segoe UI&#39;,&#39;Roboto&#39;,&#39;Oxygen&#39;,&#39;Ubuntu&#39;,&#39;Cantarell&#39;,&#39;Fira Sans&#39;,&#39;Droid Sans&#39;,&#39;Helvetica Neue&#39;,sans-serif;">
        <table cellpadding="0" width="600" cellspacing="0" border="0" style="text-align: center;margin: 0 auto;padding: 40px 100px;background: #ffff;border-radius: 5px;">
        <tr>
        <td style="padding-bottom: 40px;"> <img alt="Coinbase" width="80" src="https://www.coinbase.com/assets/app/icon_email-e8c6b940e8f3ec61dcd56b60c27daed1a6f8b169d73d9e79b8999ff54092a111.png"></td>
        </tr>
        <tr>
        <td style="color:#48545d;font-size:22px;padding-bottom: 20px;border-bottom: 1px solid #dae1e9;">Room '.$name.' Has Been Rented</td>
        </tr>
        <tr>
        <td style="color:#48545d;font-size:14px;padding: 20px 0;">
        You have received a payment of Rs. '.$fee.' from <b>'.$acc_holder.'  on '.$datetime->format('l jS \of F Y h:i:s A').'</b> for <b>'.$name.'</b> room rental </td>
        </tr>
        </table>
        </body>
        </html>';

        // html was minifier by minifycode.com
        $PHPMailer->Body = $html;

        // if the mail notification_payment was send
        if ($PHPMailer->Send()) {

          // PHPMailer class and gmail smtp data & info
          $PHPMailer = new PHPMailer;
          $PHPMailer->IsSMTP();
          $PHPMailer->Host = SMTPhost;
          $PHPMailer->SMTPAuth = true;
          $PHPMailer->SMTPSecure = 'tls';
          $PHPMailer->Port = SMTPport;
          $PHPMailer->Username = SMTPuser;
          $PHPMailer->Password = SMTPpass;

          // content email to send
          $datetime = new DateTime('NOW', new DateTimeZone('Asia/Kathmandu'));
          $PHPMailer->setFrom(SMTPuser, "noreply@studentroom");
          $PHPMailer->AddAddress($_SESSION['account']['email'] , $_SESSION['account']['user_name']);
          $PHPMailer->isHTML(true);
          $PHPMailer->Subject = "payment was successful";
          $html = '<!DOCTYPE html>
          <html lang="en" dir="ltr">
          <head>
          <meta charset="utf-8">
          <title>Payment Successful</title>
          </head>
          <body style="background: #f4f7fa;padding: 100px 0;font-family: -apple-system,BlinkMacSystemFont,&#39;Segoe UI&#39;,&#39;Roboto&#39;,&#39;Oxygen&#39;,&#39;Ubuntu&#39;,&#39;Cantarell&#39;,&#39;Fira Sans&#39;,&#39;Droid Sans&#39;,&#39;Helvetica Neue&#39;,sans-serif;">
          <table cellpadding="0" width="600" cellspacing="0" border="0" style="text-align: center;margin: 0 auto;padding: 40px 100px;background: #ffff;border-radius: 5px;">
          <tr>
          <td style="padding-bottom: 40px;"> <img alt="Coinbase" width="80" src="https://www.coinbase.com/assets/app/icon_email-e8c6b940e8f3ec61dcd56b60c27daed1a6f8b169d73d9e79b8999ff54092a111.png"></td>
          </tr>
          <tr>
          <td style="color:#48545d;font-size:22px;padding-bottom: 20px;border-bottom: 1px solid #dae1e9;">'.$name.' room payment was successful</td>
          </tr>
          <tr>
          <td style="color:#48545d;font-size:14px;padding: 20px 0;">
         Your payment ID is <strong>'.$payid.'</strong>. You make a payment of Rs.'.$fee.' to <b>'.$owner.'</b> for '.$name.' room rental on '.$datetime->format('l jS \of F Y h:i:s A').'
          </tr>
          </table>
          </body>
          </html>';

          // html was minifier by minifycode.com
          $PHPMailer->Body = $html;

          if ($PHPMailer->Send()) {

            // we update room status to 1, so we know it as rented
            mysqli_query($connect, "UPDATE room SET status = '1' WHERE id = '$id'");
            echo "payment successful <script>setTimeout(function(){self.close();},1000);</script>";
            die;
          } else {
            echo "failed to send email, please contact admin !";
            die;
          }
        }
         else {
          echo "failed to send email, please contact admin !";
          die;
        }
      // } 
      // else {
      //   echo "please fill in the payment field";
      //   die;
      // }
    } else {
      renderingLayout("payment");
      die;
    }
  } else {
    echo "<script>window.close();</script>";
    die;
  }
} else {
  header("location:../home/");
  die;
}
?>
