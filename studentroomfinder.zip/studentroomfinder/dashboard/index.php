<?php
require_once dirname(__DIR__) . '/application/src/autoload.php';

// session checking, if no set, we will continue to home
// if not set yet, we point to the home
if (isset($_SESSION['account'])) {

  // this is the delete function
  // if there is an id = parameter in the url,
  // then we know it is an item to delete
  if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $table = $_GET['table'];
    mysqli_query($connect, "DELETE FROM $table WHERE id = '$id'");
    echo "Deleting data, please wait...<meta http-equiv='refresh' content='0.0001;url=../dashboard/'>";
    die;
  }

  // simple logout function
  elseif (isset($_GET['logout'])) {
    session_destroy();
    echo "<script>window.location.reload(true);</script>";
    die;
  }

  // this if condition useful for checking whether there are any posts
  // if not we will immediately display the html layout and model
  if (!empty($_POST)) {

    if (isset($_POST['edit_profile'])) {

      // fillter all post from
      $id = $_SESSION['account']['id'];
      $username = filter_input(INPUT_POST, 'user_name', FILTER_SANITIZE_STRING);
      $password = md5(filter_input(INPUT_POST, 'password', FILTER_DEFAULT));
      $phonenumber=filter_input(INPUT_POST, 'phonenumber', FILTER_SANITIZE_STRING);

      if (!empty($_POST['password'])) {
        $query = "UPDATE account SET user_name='$username',password='$password',phonenumber='$phonenumber' WHERE id = '$id'";
      } else {
        $query = "UPDATE account SET user_name='$username' WHERE id = '$id'";
      }

      // we store data into database the update
      if (mysqli_query($connect, $query)) {
        echo "<script>alert('account successfully updated!');window.location = '../dashboard';</script>";
        die;
      }
      echo "<script>alert('Failed to Update Account!');window.location = '../dashboard';</script>";
      die;
    }

    // if there are any posts with the name=image
    // we know as submit room, because only submit rooms that use upload images
    if ($_FILES['image']) {

      // this function from http://www.geodatasource.com/developers/php
      // the code is licensed under LGPLv3
      function distance($lat1, $lon1, $lat2, $lon2, $unit) {
        if (($lat1 == $lat2) && ($lon1 == $lon2)) {
          return 0;
        }
        else {
          $theta = $lon1 - $lon2;
          $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
          $dist = acos($dist);
          $dist = rad2deg($dist);
          $miles = $dist * 1.1515;
          $unit = strtoupper($unit);
      

          if ($unit == "K") {
            return ($miles * 1.609344);
          } else if ($unit == "N") {
            return ($miles * 0.8684);
          } else {
            return $miles;
          }
        }
      }

      // filtered post
      $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
      $fee = filter_input(INPUT_POST, 'fee', FILTER_SANITIZE_STRING);
      $latitude = filter_input(INPUT_POST, 'latitude', FILTER_SANITIZE_STRING);
      $longitude = filter_input(INPUT_POST, 'longitude', FILTER_SANITIZE_STRING);
      $categories = filter_input(INPUT_POST, 'categories', FILTER_SANITIZE_STRING);
      $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
      $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
      $facilities = filter_input(INPUT_POST, 'facilities', FILTER_SANITIZE_STRING);
      $images = $_FILES['image']['name'];
      $roomowner = $_SESSION['account']['user_name'];
      $holder = $_SESSION['account']['email'];
      $contact = $_SESSION['account']['phonenumber'];

      // the rounding the result distance from the function above
      $roomdistance = distance($latitude, $longitude, latitude, longitude, 'K');
      $rounding = round($roomdistance, 2);
    

      // if result rounding distance same or no more than 7 (km)
      if ($roomdistance >= 2.5) {

        // this condition make to upload the submit image
        if (move_uploaded_file($_FILES['image']['tmp_name'], dist . "upload/" . basename($_FILES['image']['name']))) {

          // submit the data to the database
          mysqli_query($connect, "INSERT INTO room (name,fee,categories,description,address,facilities,distance,images,roomowner,holder,contact,uploaded_date) VALUES ('$name','$fee','$categories','$description','$address','$facilities','$rounding','$images', '$roomowner','$holder','$contact',NOW())");
          echo "<b>Room successfully submitted</b><meta http-equiv='refresh' content='3'>";
          die;
        } else {
          echo "failed to upload image";
          die;
        }
      } 
      else {
        echo "Sorry you cannot upload the room more than <b>2.5km</b> from the college";
        die;
      }
    }
  } else {
    renderingLayout("dashboard");
    die;
  }
} else {
  header("location:../home/");
  die;
}
?>
