<?php
require_once dirname(__DIR__) . '/application/src/autoload.php';

// session checking, if no set, we will continue to home
// if not set yet, we point to the home
if (isset($_SESSION['account'])) {

  // if change.php have id= parameter on url
  // we know as legitimate editing. if not, we point back to the dashboard
  if (isset($_GET['id'])) {

    // this if condition useful for checking whether there are any posts
    // if not we will immediately display the html layout and model
    if (!empty($_POST)) {

      // define and filtered the post//
      $id = $_GET['id'];
      $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
      $fee = filter_input(INPUT_POST, 'fee', FILTER_SANITIZE_STRING);
      $categories = filter_input(INPUT_POST, 'categories', FILTER_SANITIZE_STRING);
      $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
      $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
      $facilities = filter_input(INPUT_POST, 'facilities', FILTER_SANITIZE_STRING);
      $query = "UPDATE room SET name='$name', fee='$fee', categories='$categories', description='$description', address='$address', facilities='$facilities' WHERE id = '$id'";

      // executing the update $query to database
      if (mysqli_query($connect, $query)) {
        echo "room successfully changed <meta http-equiv='refresh' content='3;url=../dashboard/'>";
        die;
      } else {
        echo "failed to update room";
        die;
      }
    } else {
      renderingLayout("change");
      die;
    }
  } else {
    header("location:../dashboard/");
    die;
  }
} else {
  header("location:../home/");
  die;
}
?>
